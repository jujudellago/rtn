<?php if ( has_post_thumbnail() ) { ?>
	<div class="qode-course-image">
		<?php the_post_thumbnail( 'full' ); ?>
	</div>
<?php }