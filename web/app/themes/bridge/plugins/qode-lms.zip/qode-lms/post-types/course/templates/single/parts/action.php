<div class="qode-course-action">
	<?php qode_lms_get_buy_form(); ?>
</div>