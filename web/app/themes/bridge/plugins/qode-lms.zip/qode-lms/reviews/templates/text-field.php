<div class="qode-comment-input-text">
	<label><?php esc_html_e( 'Comment', 'qode-lms' ) ?></label>
	<textarea id="comment" placeholder="" name="comment" cols="45" rows="6" aria-required="true"></textarea>
</div>
