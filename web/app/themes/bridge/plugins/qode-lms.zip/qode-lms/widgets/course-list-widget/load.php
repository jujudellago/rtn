<?php

include_once QODE_LMS_ABS_PATH . '/widgets/course-list-widget/functions.php';
include_once QODE_LMS_ABS_PATH . '/widgets/course-list-widget/course-list.php';