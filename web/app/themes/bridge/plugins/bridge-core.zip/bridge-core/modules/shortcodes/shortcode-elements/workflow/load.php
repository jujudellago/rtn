<?php

require_once BRIDGE_CORE_SHORTCODES_PATH.'/workflow/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/workflow/workflow-holder.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/workflow/workflow-item.php';