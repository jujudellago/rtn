<?php

include_once QODE_TOURS_CPT_PATH . '/tours/widgets/tour-category-widget/functions.php';
include_once QODE_TOURS_CPT_PATH . '/tours/widgets/tour-category-widget/tour-categories.php';